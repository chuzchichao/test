<?php

require "vendor/autoload.php"; //载入sdk的自动加载文件
define('SITE_URL', 'http://localhost/PayPal'); //网站url自行定义
//创建支付对象实例
$paypal = new \PayPal\Rest\ApiContext(
    new \PayPal\Auth\OAuthTokenCredential(
        'AUbuInfjIOXtVsKabU_YQCgvNe6kuTpYaAfw6vnM7qgg4Ty6sOG5nZmrc_ufMPptZcIl2TjegxUW3xHZ',
        'EHrKyriTubpLAXbngYFUp9lhy5JKNgoPcw3nlqwTlj89UWx41akSPBKRq5mo-XGuvbxH3TJ9k-zOV-Fy'
    )
);

?>